const members = [
    {
      ID: 1,
      NIM: '105022210044',
      Nama: 'Jonathan Kieron Medellu',
      Phone: '081235766445',
    },
    {
      ID: 2,
      NIM: '105022310054',
      Nama: 'Kevin Wijaya Tjiu',
      Phone: '08219964777',
    },
  ];
  
  module.exports = members;
  